# deCDN Press Kit

Everything press, partners, and journalists need to write about deCDN.
For questions or interview requests: <info@decdn.org>

---

## About deCDN

### Short (50 words)

deCDN is a peer-to-peer content delivery network. Node operators stake tokens, cache BLAKE3-addressed blobs, and earn USDC for every megabyte they serve. The result: cryptographically verified delivery at roughly $0.01/GB — up to 90% cheaper than legacy CDNs — with no single point of failure and no subscription lock-in.

### Medium (100 words)

deCDN is a peer-to-peer content delivery network — an open delivery layer for the internet. Operators stake tokens, cache BLAKE3-addressed content, and earn USDC for every megabyte they serve. Clients probe available nodes for latency and price over QUIC, then stream directly from the winning peer — every byte cryptographically verified, every payment cleared through off-chain USDC channels. The target rate is around $0.01/GB, up to 90% cheaper than centralized CDNs. There is no single point of failure: cache misses trigger paid peer pulls that warm the network around real demand.

### Long (250 words)

deCDN is a peer-to-peer content delivery network — an open, programmable delivery layer for any large file. Today's distribution depends on a handful of centralized providers charging $0.04–$0.20 per gigabyte for plaintext-at-the-edge delivery, with no operator transparency and no way for anyone outside the incumbents to participate in the market.

deCDN replaces that bottleneck with a peer-to-peer mesh. Node operators stake tokens, cache BLAKE3-addressed content, and earn USDC for every megabyte they serve. Clients probe available nodes for latency and price over QUIC (0-RTT), then stream directly from the winning peer — every byte cryptographically verified against its content hash, every payment cleared through off-chain USDC channels with on-chain dispute resolution. The target rate is around $0.01/GB, up to 90% cheaper than legacy CDNs, with no subscription lock-in.

The architecture is verifiable by construction: corrupted or phantom-announced content is instantly detectable and slashable. End-to-end encryption keeps content opaque to operators while preserving global cacheability. The network self-heals — cache misses trigger paid peer pulls that warm the grid around demand.

Built in Rust on the iroh QUIC stack, with USDC for payments and a native TOKEN for staking, governance, and fee discounts. The initial deployment targets tens of nodes on an Arbitrum Sepolia testnet, with production launch planned on Arbitrum One.

---

## Fact Sheet

| | |
|---|---|
| **Name** | deCDN |
| **Category** | Decentralized infrastructure (DePIN) / content delivery |
| **Founded** | May 2026 |
| **Headquarters** | Switzerland |
| **Stage** | Early implementation, pre-seed |
| **Team size** | 4 |
| **Tech stack** | Rust, iroh (QUIC transport, NAT traversal, content-addressed blobs), BLAKE3, USDC, Arbitrum |
| **Network milestone** | Tens of nodes on Arbitrum Sepolia testnet; production deployment on Arbitrum One planned within 6–8 months of funding |
| **Website** | <https://decdn.org> |
| **X / Twitter** | <https://x.com/decdnorg> |
| **GitHub** | <https://github.com/decdn> |
| **Press contact** | <info@decdn.org> |

### Founders

- **Alper Gundogdu — CEO.** Cryptocurrency and infrastructure veteran, ex-Googler. - <alper@decdn.org>
- **Ant Somers — CTO.** Continental-scale RPC and distributed-systems experience. - <ant@decdn.org>
- **Yigit Gurbulak — Protocol engineer.** Rust + cryptography. - <yigit@decdn.org>
- **Altan Oruc — Quantitative researcher.** Markets, incentives, economic stability. - <altan@decdn.org>

### Key facts press can quote

- Target delivery rate: **~$0.01/GB** (up to 90% cheaper than centralized CDNs at $0.04–$0.20/GB).
- All delivery payments settled in **USDC** — no token-price volatility for operators.
- Content is **BLAKE3-addressed**; every byte is cryptographically verified end-to-end.
- Transport: **QUIC with 0-RTT** probing; target P50 cache-miss latency 50–100 ms.
- **20% of protocol fees** flow into a Balancer V3 80/20 pool for automated buyback-and-burn.

---

## Brand Guidelines

### Colors

| Token   | Hex       | Use                                              |
|---------|-----------|--------------------------------------------------|
| ink     | `#000000` | Body text, dark-mode backgrounds                 |
| paper   | `#ffffff` | Light-mode backgrounds, text on ink              |
| whisper | `#0f9d6a` | Accent — the underscore, links, highlights       |

### Typography

- **Brand mark:** Geist-Bold (weight 700). Same font, same weight, every use.
- **Body copy:** Geist Regular.
- **Voice:** lowercase by default — headlines, section titles, and CTA labels stay lowercase unless quoting a proper noun or a brand outside our control.
- **Brand name in prose:** Both `decdn` (matching the voice) and `deCDN` (mixed case, for emphasis or readability) are fine. The underscored form `decdn_` is reserved for the visual mark — don't use it in flowing text.

### Logo Usage

Files live in `logos/`.

- **Wordmark** (`wordmark-light.svg`, `wordmark-dark.svg`) — the full `decdn_` lockup. Use at header sizes (24–40 px tall) or anywhere with horizontal room. Light variant on light backgrounds; dark variant on dark backgrounds.
- **Logomark** (`logomark-light.svg`, `logomark-dark.svg`, `logomark-180.png`) — the square `d_` mark. Use at tab-icon, avatar, and small-chip sizes (≤ 32 px). The 180 px PNG is for Apple touch icons.

### Do / Don't

**Do**

- Keep the whisper-green underscore — it's the load-bearing piece of the brand.
- Use the wordmark for headers; logomark for small marks.
- Preserve the 12-unit corner radius on the logomark's rounded square.

**Don't**

- Replace the underscore with a period.
- Recolor the underscore — whisper-green only.
- Stretch, distort, or skew either asset.
- Mix font weights — the mark is always Geist-Bold, never Regular or Medium.

---

```{=typst}
#pagebreak()
```

## Contents of this kit

```
Presskit/
├── README.md                       markdown source — grep, copy/paste
├── README.pdf                      about, fact sheet, brand guide
└── logos/
    ├── wordmark-light.svg          header lockup, light backgrounds (scalable)
    ├── wordmark-dark.svg           header lockup, dark backgrounds (scalable)
    ├── wordmark-light-1024.png     1024×275 raster, light backgrounds
    ├── wordmark-light-2048.png     2048×549 raster, light backgrounds
    ├── wordmark-dark-1024.png      1024×275 raster, dark backgrounds
    ├── wordmark-dark-2048.png      2048×549 raster, dark backgrounds
    ├── logomark-light.svg          square mark, light backgrounds (scalable)
    ├── logomark-dark.svg           square mark, dark backgrounds (scalable)
    ├── logomark-light-1024.png     1024×1024 raster, light backgrounds
    ├── logomark-light-2048.png     2048×2048 raster, light backgrounds
    ├── logomark-dark-1024.png      1024×1024 raster, dark backgrounds
    ├── logomark-dark-2048.png      2048×2048 raster, dark backgrounds
    └── logomark-180.png            180×180 raster (Apple touch icon)
```
